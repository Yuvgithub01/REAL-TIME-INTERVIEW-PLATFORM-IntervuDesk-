export default {
  providers: [
    {
      domain: "https://romantic-escargot-62.clerk.accounts.dev",
      applicationID: "convex",
    },
  ]
};

// https://romantic-escargot-62.clerk.accounts.dev